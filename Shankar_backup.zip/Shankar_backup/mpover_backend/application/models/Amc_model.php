<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Amc_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		
    }
    function index(){
        $data = array(            
            'vehicle_number' => $_POST['vehicle_number'],
            'reg_id' => $_POST['reg_id'],            
            'end_date' => $_POST['end_date'],
            'vehicle_type' => $_POST['vehicle_type'],
            'status' => $_POST['status'],
            'brand_model' => $_POST['brand_model'],
            'brand_name' => $_POST['brand_name'],
            'customer_id' => $_POST['customer_id']
                    
        );
        $this->db->insert('amc_register',$data);
        $result = $this->db->insert_id();
        return $result; 
    }
		

}