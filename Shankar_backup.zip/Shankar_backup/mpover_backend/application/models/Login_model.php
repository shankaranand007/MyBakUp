<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model{
	public function __construct()
	{
		parent::__construct();
		
		
    }
    function index(){
		$email = $_POST['email'];
		$this->db->select('*');
		$this->db->from('signup');
		$this->db->where("(email = '$email' OR mobile_number = '$email')");
		$this->db->where('password', $_POST['password']);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "Email or Password is wrong";
			return $results;
		} else {
			return $results;
		}        
    }

}