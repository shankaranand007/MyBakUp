<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* 
*
* Class: Login
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Login
* @category   Rest API
* @author     Vignessh A
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/
error_reporting(0);
require APPPATH.'/libraries/REST_Controller.php';


class Login extends REST_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation'); // Library use to validate given input.
		$this->load->model('login_model');
		$this->form_validation->set_error_delimiters('', '');
		
	}
	
	// Function : Index 
	// Method : post
	
	public function index_post() {
		
		$input_data = json_decode(trim(file_get_contents('php://input')), true);
		$post_key = array_keys($input_data);
		foreach($input_data as $key=>$val){
			$_POST[$key] = $val;
		}
			
		if(isset($_POST) != "") {

			$pre_key = array('email','password');
			
			// Empty key checking.
			$result=array_diff($pre_key,$post_key);
			if(!empty($result)) {
				$resc = "";
				foreach($result as $res){
					$resc .= $res.',';
				}
				$resc = substr($resc,0,-1) ;
	
				$result = Array ( "result" => "" );
				$msg = array("error_code" => "0", "msg" =>$resc, "result" => $result);
				$this->response($msg, 202);
	
			} else {
				$this->form_validation->set_rules('email', 'email', 'trim|required');
				$this->form_validation->set_rules('password', 'password', 'trim|required');
				
				if($this->form_validation->run() == FALSE)
				{
					$result = Array("result" => "");
					$msg = array("error_code" => "1", "msg" => "Error", "result" => validation_errors());
					$this->response($msg, 202);
	
				}
				else {
					$this->db->select('*');
					$this->db->from('signup');
					$this->db->where('email',$_POST['email']);
					$this->db->where('status',1);
					$query = $this->db->get();
					$results = $query->result_array();
					//print_r(sizeof($results));
					if(sizeof($results)==0)
					{
						$result = "Email not registered";
						$msg = array("error_code" => "1","msg" => "Error", "result" => $result);
						$this->response($msg, 202);
					} else {
						$result = $this->login_model->index();
						$msg = array("error_code" => "1", "msg" => "Success", "result" => $result);
						$this->response($msg, 202);
					}
					
				}

			}
					
		}
		
		else { 		
			$result = "Invalid Data";
			$msg = array("error_code" => "1","msg" => "Error","result" => $result);
			$this->response($msg, 202);	
		}
		
	 }	
}
