<?php if(! defined('BASEPATH')) exit('No direct script access allowed');
/* 
*
* Class: Customerinfo
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Customerinfo
* @category   Rest API
* @author     Aravinthakumar S
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/
require APPPATH.'libraries/REST_Controller.php';

class Customerinfo extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');	
		$this->form_validation->set_error_delimiters('','');
	}
	
	public function custview_post()
	{
		$this->db->select('*');
		$this->db->from('customer');
		$this->db->where('status',1);		
		$query=$this->db->get();
		$resp=$query->result_array();
		$msg=array("error"=>1,"msg"=>"success","result"=>$resp);
		$this->response($msg,202);
	}
	
	
	public function custeditview_post()
	{
		$this->db->select('*');
		$this->db->from('customer');
		$this->db->where('status',1);		
		$this->db->where('cust_id', $_POST['cust_id']);
		$query=$this->db->get();
		$resp=$query->result_array();
		$msg=array("error"=>1,"msg"=>"success","result"=>$resp);
		$this->response($msg,202);
	}
	
	
	public function custdelete_post()
	{
		$data=array(		      
		'status'  => '0'
		);
		$this->db->where('cust_id',$_POST['cust_id']);
		$this->db->where('status',1);
		$this->db->update('customer',$data);	
		$affected=$this->db->affected_rows();
		$msg=array("error"=>1,"msg"=>"Success","Results"=>$affected);
		$this->response($msg,202);
	}
	public function custedit_post()
	{
		
		$data=array(		
		'name'  => $_POST['name'],		
		'email'     => $_POST['email'],
        'address' => $_POST['address'], 
		'city' => $_POST['city'], 
        'state'  => $_POST['state'],        
		'mobile'  => $_POST['mobile']
		);
		$this->db->where('cust_id',$_POST['cust_id']);
		$this->db->where('status',1);
		$this->db->update('customer',$data);
		$this->get_pincode($_POST['zip'],$_POST['cust_id']);
		$affected=$this->db->affected_rows();
		$msg=array("error"=>1,"msg"=>"Success","Results"=>$affected);
		$this->response($msg,202);
		
	}
	
	function get_pincode($pincode,$cust_id){
		
		$url = "https://maps.googleapis.com/maps/api/geocode/json?address=".$pincode."&sensor=false&key=AIzaSyAdhO5c8BfCA84X5JqfEHSKZQyEVoPoeiA";
		$details=file_get_contents($url);
		$result = json_decode($details,true);
		$status = $result['status'];
		if($status == "OK"){
			$lat=$result['results'][0]['geometry']['location']['lat'];
			$lng=$result['results'][0]['geometry']['location']['lng'];
		}
		else{
			
			$lat="000";
			$lng="000";
		}
		
		$this->load->model('Customerinfo_model');
		return $result = $this->Customerinfo_model->lat_long_update($pincode,$lat,$lng,$cust_id);
	}
	
	
}
