<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category_model extends CI_Model{
	public function __construct()
	{
		parent::__construct();
    }
	
    function index(){
        $data = array(
            category_name =>$_POST['category_name'],
            category_type =>"1"
        );
		$this->db->insert('product_category',$data);
        $result = $this->db->insert_id();
        return $result; 
    }
	
	function upload(){
        $data = array(
            category_name =>$_POST['category_name'],
			category_image =>$_POST['file'],
            category_type =>"1"
        );
		$this->db->insert('product_category',$data);
        $result = $this->db->insert_id();
        return $result; 
    }

}