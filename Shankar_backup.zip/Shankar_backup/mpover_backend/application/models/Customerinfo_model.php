<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customerinfo_model extends CI_Model{
	public function __construct()
	{
		parent::__construct();		
		
    }
function lat_long_update($pincode,$lat,$lng,$cust_id){
		
		    $data = array(
        		  'latitude'  => $lat,
				  'longitude'  => $lng,
				  'zip' => $pincode	  
				  
    			);
		    $this->db->where('cust_id',$cust_id);
        	$this->db->update("customer",$data);
        	$result = $this->db->insert_id();
		return $result;
	}
}