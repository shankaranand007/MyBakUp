<?php

error_reporting(0);
	class validationandresult {
		
		
		
		function keyvalidation($pre_key,$mode,$api_name,$parameter) {
			
			
				
			$results=array_diff($pre_key,$parameter);
			$resc = implode(",",$results);
			$result = array ( "result" => "" );
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => "0","message" => $resc,"result" => $result);
			return $message;
			
			
		}
		function keyvalidations_custom($pre_key,$req_key,$decoded){
			
			
		   $validate= true;
		   $message="";
			
			foreach($req_key as $val){
							
				if($decoded[$val]==""){
					
					$validate= false;
					$message .= $val. " field is required,";
					
				}
               
			  
				
			}
			$message = rtrim($message, ',');
			
			$error = $message;
			
			
			
			
			$result = array ( "result" => "" );
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => "0","message" => $error,"result" => $result);
			return $message;
		}
		function keyvalidations($pre_key,$mode,$api_name){
			
			$result = array ( "result" => "" );
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => "0","message" => "","result" => $result);
			return $message; 
			
		}
		function modeerror($mode,$api_name){
			
			$result = array ( "result" => "" );
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => "0","message" => "Invalid Request!","result" => $result);
			return $message;
			
		}
		function invalidrequest_error($mode,$api_name){
			
			$result = array ( "result" => "" );
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => "0","message" => "Invalid Request!","result" => $result);
			return $message;
		}
		function formvalidation($validation_errors,$mode,$api_name) {
			
			
			$result = array ( "result" => "" );
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => "0","message" => $validation_errors,"result" => $result);
			return $message;
			
			
		}
		
		function successmessagewithemptyresult($mode,$api_name) {
			
			
			$result = array ( "result" => "" );
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => "1","message" => $validation_errors,"result" => $result);
			
			return $message;
			
			
		}
		
		function successmessagewithresult($result,$mode,$api_name) {
			
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => "1","message" => "success","result" => $result);
			return $message;
			
			
		}
		
		function custommessage($message,$mode,$api_name) {
			
			$result = array ( "result" => "" );
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => "1","message" => $message,"result" => $result);
			
			return $message;
			
			
		}
		function custom_message($message,$mode,$api_name,$code) {
			
			$result = array ( "result" => "" );
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => $code,"message" => $message,"result" => $result);
			
			return $message;
			
			
		}
		function successmessagewithemptyresultzero() {
			
			
			$result = array ( "result" => "" );
			$message = array("StatusCode" => "0","message" => "success","result" => $result); 
			return $message;
			
			
		}
		function invalidrequest($mode,$api_name) {
			
			
			$result = array ( "result" => "" );
			$message = array("mode" => $mode,"api_name" => $api_name,"response_code" => "0","message" => $validation_errors,"result" => $result);
			
			return $message;
			
			
		}
		
		function accountclosed() {
			
			
			$result = array ( "result" => "" );
			$message = array("StatusCode" => "0","message" => "Account closed.","result" => $result);
			return $message;
			
			
		}
		
		
	}
 ?>