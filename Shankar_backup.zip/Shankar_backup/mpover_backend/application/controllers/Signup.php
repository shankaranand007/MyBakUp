	<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* 
*
* Class: Api_registration
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Api_registration
* @category   Rest API
* @author     Shankar Anand A
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/

error_reporting(0);
require APPPATH.'/libraries/REST_Controller.php';


class Signup extends REST_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation'); // Library use to validate given input.
		$this->load->model('signup_model');
		$this->form_validation->set_error_delimiters('', '');
		
	}
	
	public function index_post() {
		$otp = mt_rand(100000, 999999);
		$input_data = json_decode(trim(file_get_contents('php://input')), true);
			
		$post_key = array_keys($input_data);
		foreach($input_data as $key=>$val){
			$_POST[$key] = $val;
		}
			
		if(isset($_POST) != "") {
			
			$pre_key = array('mobile');

			$result=array_diff($pre_key,$post_key);
			if(!empty($result)) {
				$resc = "";
				foreach($result as $res){
					$resc .= $res.',';
				}
				$resc = substr($resc,0,-1) ;
				$result = Array ( "result" => "" );
				$msg = array("error_code" => "0", "msg" =>$resc, "result" => $result);
				$this->response($msg, 202);
	
			} else {
				
					$this->db->select('mobile');
					$this->db->from('register');
					$this->db->where('mobile',$_POST['mobile']);
					$query = $this->db->get();
					$results = $query->result_array();
					if(sizeof($results) == 0 || sizeof($results) == "0"){
						$mob =$_POST['mobile'];
						$message = $otp;
						$test = $this->send_sms($mob,$otp);
					$result = $this->signup_model->otp($otp);
					$msg = array("error_code" => "1", "msg" => "Success", "result" => $test);
					$this->response($msg, 202);
					}else{

					$msg = array("error_code" => "0", "msg" => "Mobilenumber already regeister", "result" => "");
						$this->response($msg, 202);
					}
					
				}

		}
					
	}
	
public function reg_post() {
		
		$input_data = json_decode(trim(file_get_contents('php://input')), true);
			
		$post_key = array_keys($input_data);
		foreach($input_data as $key=>$val){
			$_POST[$key] = $val;
		}
			
		if(isset($_POST) != "") {
			
			$pre_key = array('type','name','email','city','state','zip','address');

			$result=array_diff($pre_key,$post_key);
			// if(!empty($result)) {
			// 	$resc = "";
			// 	foreach($result as $res){
			// 		$resc .= $res.',';
			// 	} 
			// 	$resc = substr($resc,0,-1) ;
	
			// 	$result = Array ( "result" => "" );
			// 	$msg = array("error_code" => "0", "msg" =>$resc, "result" => $result);
			// 	$this->response($msg, 202);
	
			// } else 
			{
					$result = $this->signup_model->index();
					
					//Get pincode 
					//$pincode = 600091;
					$pincode = $_POST['zip'];
					//Calling lat/long update function 
					$get_pincode = $this->get_dealer_pincode($pincode);
					
					$msg = array("error_code" => "1", "msg" => "Success", "result" => $result);
					$this->response($msg, 202);
			}

		}
					
	}

	function send_sms($mob,$otp)
		{


					// Replace with your username
					$user = "sskumar_p";

					// Replace with your API KEY (We have sent API KEY on activation email, also available on panel)
					$apikey = "ekvps2XEvt2r95tW60Qk"; 

					// Replace if you have your own Sender ID, else donot change
					$senderid  =  "MYTEXT"; 

					// Replace with the destination mobile Number to which you want to send sms
					$mobile  =  $mob; 

					// Replace with your Message content
					$message   =  $otp; 
					$message = urlencode($message);

					// For Plain Text, use "txt" ; for Unicode symbols or regional Languages like hindi/tamil/kannada use "uni"
					$type   =  "txt";

					$ch = file_get_contents("http://smshorizon.co.in/api/sendsms.php?user=".$user."&apikey=".$apikey."&mobile=".$mobile."&senderid=".$senderid."&message=".$message."&type=".$type.""); 
				
					    $output = $ch;      

					 return $output;


		}

	public function resend_otp_post() {
		$otp = mt_rand(100000, 999999);
		$input_data = json_decode(trim(file_get_contents('php://input')), true);
			
		$post_key = array_keys($input_data);
		foreach($input_data as $key=>$val){
			$_POST[$key] = $val;
		}
			
		if(isset($_POST) != "") {
			
			$pre_key = array('mobile');

			$result=array_diff($pre_key,$post_key);
			if(!empty($result)) {
				$resc = "";
				foreach($result as $res){
					$resc .= $res.',';
				}
				$resc = substr($resc,0,-1) ;
	
				$result = Array ( "result" => "" );
				$msg = array("error_code" => "0", "msg" =>$resc, "result" => $result);
				$this->response($msg, 202);
	
			} else {
						$mob =$_POST['mobile'];
						$message = $otp;
						$test = $this->send_sms($mob,$otp);
					$result = $this->signup_model->resend_otp($otp);
					$msg = array("error_code" => "0", "msg" => "Success", "result" => $test);
					$this->response($msg, 202);
			}

		}
					
	}	

	function verify_post(){
		$input_data = json_decode(trim(file_get_contents('php://input')), true);
		$post_key = array_keys($input_data);
		foreach($input_data as $key=>$val){
			$_POST[$key] = $val;
		}
			
		if(isset($_POST) != "") {
			
			$pre_key = array('otp','mobile');

			$result=array_diff($pre_key,$post_key);
			if(!empty($result)) {
				$resc = "";
				foreach($result as $res){
					$resc .= $res.',';
				}
				$resc = substr($resc,0,-1) ;
	
				$result = Array ( "result" => "" );
				$msg = array("error_code" => "0", "msg" =>$resc, "result" => $result);
				$this->response($msg, 202);
	
			} else {
					$this->db->select('mobile,otp,reg_id');
					$this->db->from('register');
					$this->db->where('otp',$_POST['otp']);
					$this->db->where('mobile',$_POST['mobile']);
					$query = $this->db->get();
					$results = $query->result_array();

					if(sizeof($results) == 0){
						$msg = array("error_code" => "0", "msg" => "Not match", "result" => "");
					$this->response($msg, 202);
						}else{
							$result = $this->signup_model->status_update($results[0]['reg_id']);
						$msg = array("error_code" => "1", "msg" => "OTP matched", "result" =>$result);
					$this->response($msg, 202);
						}
					
			}

		}
	}




	function signin_post(){
		$input_data = json_decode(trim(file_get_contents('php://input')), true);
		$post_key = array_keys($input_data);
		foreach($input_data as $key=>$val){
			$_POST[$key] = $val;
		}
			
		if(isset($_POST) != "") {
			
			$pre_key = array('password','mobile');

			$result=array_diff($pre_key,$post_key);
			if(!empty($result)) {
				$resc = "";
				foreach($result as $res){
					$resc .= $res.',';
				}
				$resc = substr($resc,0,-1) ;
	
				$result = Array ( "result" => "" );
				$msg = array("error_code" => "0", "msg" =>$resc, "result" => $result);
				$this->response($msg, 202);
	
			} else {
					$this->db->select('*');
					$this->db->from('register');
					$this->db->where('password',$_POST['password']);
					$this->db->where('mobile',$_POST['mobile']);
					$this->db->where('status',1);
					$query = $this->db->get();
					$results = $query->result_array();

					if(sizeof($results) == 0){
						$msg = array("error_code" => "0", "msg" => "Signin noo", "result" => "");
					$this->response($msg, 202);
						}else{
							
						$msg = array("error_code" => "1", "msg" => "Signin", "result" =>$results);
					$this->response($msg, 202);
						}
					
			}

		}
	}
	
	function get_dealer_pincode($pincode){
		
		$url = "https://maps.googleapis.com/maps/api/geocode/json?address=".$pincode."&sensor=false&key=AIzaSyAdhO5c8BfCA84X5JqfEHSKZQyEVoPoeiA";
		$details=file_get_contents($url);
		$result = json_decode($details,true);
		$status = $result['status'];
		if($status == "OK"){
			$lat=$result['results'][0]['geometry']['location']['lat'];
			$lng=$result['results'][0]['geometry']['location']['lng'];
		}
		else{
			
			$lat="000";
			$lng="000";
		}
		
		//Update Latitude/Longitude corrusponding to Pincode
		return $result = $this->signup_model->lat_long_update($pincode,$lat,$lng);
	}
}
