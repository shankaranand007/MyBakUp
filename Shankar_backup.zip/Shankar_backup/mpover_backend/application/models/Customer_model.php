<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_model extends CI_Model{
	public function __construct()
	{
		parent::__construct();
		
		
    }
    function index(){

        if(isset($_POST['password']) || !empty($_POST['password'])){
            $d_id = $_POST['password'];
        }else{
            $d_id = 0;
        }
        if(!isset($_POST['status']) || empty($_POST['status']) || $_POST['status'] == null || $_POST['status'] == undefined){
                $data = array(
            type => 2,
            name  => $_POST['name'],
            email     => $_POST['email'],
            address => $_POST['address'],
            city => $_POST['city'],
            state  => $_POST['state'],
            zip  => $_POST['zip'],
            // img  => $_POST['img'],
            password  => $d_id
        );

        $this->db->where('mobile',$_POST['mobile']);
        $this->db->update("customer",$data);
 
        $resut = $this->db->insert_id();

        }else{
                $data = array(
            type => 2,
            name  => $_POST['name'],
            email     => $_POST['email'],
            address => $_POST['address'],
            city => $_POST['city'],
            state  => $_POST['state'],
            zip  => $_POST['zip'],
            // img  => $_POST['img'],
            password  => $d_id,
            status =>$_POST['status'],
            mobile =>$_POST['mobile'],
        );
        $this->db->insert("customer",$data);
        $resut = $this->db->insert_id();
        }

    
        return $resut; 
    }

    function otp($otp){
        if(isset($_POST['device_id']) || !empty($_POST['device_id'])){
            $d_id = $_POST['device_id'];
        }else{
            $d_id = 0;
        }
        $data = array(
            mobile => $_POST['mobile'],
            otp   => $otp,
            device_id => $d_id,
            status  => 0,
        );
        $this->db->insert('customer',$data);
        $resut = $this->db->insert_id();
        return $resut; 
    }

    function resend_otp($otp){
    $data = array(
        otp   => $otp,
        status  => 0
      
    );
        $this->db->where('mobile',$_POST['mobile']);
        $this->db->update("customer",$data);
        $resut = $this->db->insert_id();
    return $resut; 
}
	function status_update($value){
		    $data = array(
        		  status  => 1
    			);
		    $this->db->where('cust_id',$value);
        	$this->db->update("customer",$data);
        	$resut = $this->db->insert_id();
		return $resut;
	}
	
	function lat_long_update($pincode,$lat,$lng){
		
		    $data = array(
        		  latitude  => $lat,
				  longitude  => $lng,
    			);
		    $this->db->where('zip',$pincode);
        	$this->db->update("customer",$data);
        	$result = $this->db->insert_id();
		return $result;
	}
}