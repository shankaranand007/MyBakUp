<?php
class variableconfig {
 
}
