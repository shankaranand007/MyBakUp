import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import Index from './landingpage/Index.jsx';
import Header2 from './common/Header2.jsx';
import Side_filter from './common/side_filter/Side_filter.jsx';
import Compare from './compare/Compare.jsx';



class App extends Component {
  render() {
    return (
      <div>
      {/* <Header2 />
      <Index />
      <Side_filter/> */}
      <Compare />
      </div>
    );
  }
}

export default App;
