import React, { Component } from 'react';
import './filter.css';
// import logo from '../assets/logo.png';
// import { Navbar,Nav,NavItem,NavDropdown,MenuItem} from 'react-bootstrap';
import Header2 from '../Header2.jsx';
import RangeSlider from 'react-dual-rangeslider';
import { FormGroup,Radio} from 'react-bootstrap';
import { Button,Grid, Segment,Checkbox } from 'semantic-ui-react'
  
export default class Side_filter extends Component {
    render() {
      return (
        <div>
       <Header2 />
       <Grid>
    <Grid.Column floated='left' width={4}>
    <div className="sidebar">
       <FormGroup>
                          
       <label htmlFor="">Gender &nbsp;:&nbsp;</label><br/>
                        <Radio name="radioGroup" inline >
                                Male
                              </Radio>{' '}
                              <Radio name="radioGroup" inline>
                                Female
                              </Radio>{' '}
                              <Radio name="radioGroup" inline>
                                Others
                              </Radio>
                          </FormGroup>
                          <div className="line2" ></div>
                          <p style={tag}>Budget</p>
                            <RangeSlider
                              min={0}
                              max={1000}
                              minRange={10}
                              // onChange={(state)=>{
                              //     console.log('react-dual-rangeslider max: ', state.max);
                              //     console.log('react-dual-rangeslider min: ', state.min);
                              // }}
                              step={1}
                          />
                           <div className="line2" ></div>
                          <p style={tag}>Distance from your location</p>
                            <RangeSlider
                              min={1}
                              max={10}
                              minRange={1}
                              // onChange={(state)=>{
                              //     console.log('react-dual-rangeslider max: ', state.max);
                              //     console.log('react-dual-rangeslider min: ', state.min);
                              // }}
                              step={1}
                          />
                          <div className="line2" ></div>
                           <FormGroup>
                          
                          <label htmlFor="">Sharing &nbsp;:&nbsp;</label><br/>
                                           <Radio name="radioGroup" inline >
                                                   1x
                                                 </Radio>{' '}
                                                 <Radio name="radioGroup" inline>
                                                   2x
                                                 </Radio>{' '}
                                                 <Radio name="radioGroup" inline>
                                                   3x
                                                 </Radio>
                                                 <Radio name="radioGroup" inline>
                                                   4x
                                                 </Radio>
                                             </FormGroup>
                                             <div className="line2" ></div>
                                             <FormGroup>
                                             <Checkbox label='WIFI' />
                                             <Checkbox label='TV' />
                                             <Checkbox label='Camera' />
                                             <Checkbox label='A/C' />
                                             <Checkbox label='Hot Water' />
                                             <Checkbox label='Attached bathroom' />
                                             <Checkbox label='Cooking' />
                                             <Checkbox label='Meals' />
                                             <Checkbox label='Non-Veg' />
                                             <Checkbox label='Warden' />
                                             <Checkbox label='Whashing Machine' />
                                             <Checkbox label='Cupboard' />
                                             <Checkbox label='Romm cleaning' />
                                             <Checkbox label='Parking' />
                                             </FormGroup>
                                             <Button color='green' className="bt2">Apply</Button>
                                             
       </div>
    </Grid.Column>
  </Grid>

        </div>
      );
    }
  }
  var tag = {
    position: 'absolute',
  right: 0,
  left: 0,
  'text-align': 'center'
    
  }
var btn = {
  background:'#00b12'
}