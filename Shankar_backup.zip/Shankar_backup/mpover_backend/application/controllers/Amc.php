<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* 
*
* Class: Api_Brand
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Api_Brand
* @category   Rest API
* @author     Aravinthakumar S
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/

require APPPATH.'/libraries/REST_Controller.php';

class Amc extends REST_Controller 
{
	
	public function __construct()
	{
		parent::__construct();		
		$this->load->model('Amc_model');		
	}
	
	public function index_post()
	{
		if(isset($_POST)!= "")
		{
			
			$post_key = array_keys($_POST);			
			$pre_key = array('vehicle_number','reg_id','end_date','vehicle_type','brand_model','status','brand_name','customer_id');
			$result=array_diff($pre_key,$post_key);			
			if(!empty($result))
			{
				$res="";
				foreach($result as $resp)
				{
					$res.=$resp;
				}
				$res=substr($res,0,-1);
				$result=array("result"=>"");
				$msg= array("error_code"=>"0","msg"=>$res,"result"=>$result);
				$this->response($msg,202);
			}
			else
			{
				$result = $this->Amc_model->index();
				$msg=array("error_code"=>"1","msg"=>"Success","result"=>$result);
				$this->response($msg,202);
			}
		}
		else
		{
			$result = "invalid";
	 		$msg = array("error_code" => "1","msg" =>"fail","result" => $result);
	 		$this->response($result, 201);
		}
		
	}
	
	function Amcactiveview_post()
	 {	 	
	 	
		$this->db->select('*');
		$this->db->from('amc_register');
		$this->db->where('status',1);
		$query = $this->db->get();
		$afftected = $query->result_array();	 		
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftected);
	    $this->response($msg,202);
	 }
	 
	 function Amcinactiveview_post()
	 {	 	
	 	
		$this->db->select('*');
		$this->db->from('amc_register');
		$this->db->where('status',0);
		$query = $this->db->get();
		$afftected = $query->result_array();	 		
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftected);
	    $this->response($msg,202);
	 }
	 
	 function Amcviewedit_post()
	 {	 	
	 	
		$this->db->select('*');
		$this->db->from('amc_register');
		$this->db->where('amc_id',$_POST['amc_id']);
		$query = $this->db->get();
		$afftected = $query->result_array();	 		
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftected);
	    $this->response($msg,202);
	 }
	 
	
	function Amcedit_post()
	 {
	 	$data = array(
            'vehicle_number' => $_POST['vehicle_number'],
            'reg_id' => $_POST['reg_id'],            
            'end_date' => $_POST['end_date'],
            'vehicle_type' => $_POST['vehicle_type'],
            'status' => $_POST['status'],
            'brand_model' => $_POST['brand_model'],
            'brand_name' => $_POST['brand_name'],
            'customer_id' => $_POST['customer_id']
        );
	 	$this->db->where("amc_id",$_POST['amc_id']);
	 	$this->db->update("amc_register",$data);
	 	$afftectedRows = $this->db->affected_rows();
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftectedRows);
	    $this->response($msg,202);
	 }
		
	
	
	
}
?>