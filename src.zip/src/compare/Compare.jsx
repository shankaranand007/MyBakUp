import React, { Component } from 'react';
import './compare.css';
import Side_filter from '../common/side_filter/Side_filter.jsx';
import { FormGroup,Radio} from 'react-bootstrap';
 import { Button,Grid, Segment,Checkbox } from 'semantic-ui-react'

export default class Compare extends Component {
    render(){
        return(
            <div>
                <Side_filter />
   <Grid>
    <Grid.Column  width={4}>
    </Grid.Column>
    <Grid.Column  width={4}>
    
    <div className="line3" ></div>
                <div className="compare">
                <div style={rating}>
                <h4 style={{ 'background-color': '#00b125',
                 'border-radius': '31px','text-color':'white',color:'white','padding':'9px'}}>4.3</h4>
                <span>*****</span><br/>
                {/* <span style={{}}>7 Reviews</span> */}
                </div>
                
                      <FormGroup className="side_line"> 
                         <h4 style={bt}>Grand Boys Pg</h4>
                         
                        <Radio name="radioGroup" inline >
                        gh
                              </Radio>{' '}
                              <Radio name="radioGroup" inline>
                              gf
                              </Radio>{' '}
                              <Radio name="radioGroup" inline>
                              2 views
                              </Radio>
                              
                          </FormGroup>
                         
                         
                          <div className="line3" ></div>
                          <div style={{"float":'right',    'margin-left':' 2px',
                          'margin-right': '-83px',
                          'margin-top': '5px'}}>
                          <span style={{'font-weight':'bold'}}>Deposit:</span><span style={bt}>1 Month Rent</span>
                          </div>
                           <FormGroup className="side_line">
                              <span style={bt}>4.2km</span> <span >From your location</span>
                                             </FormGroup>
                                             <div className="line3" ></div>
                                             <FormGroup>
                                             <Checkbox label='WIFI' />
                                             <Checkbox label='TV' />
                                             <Checkbox label='Camera' />
                                             <Checkbox label='A/C' />
                                             <Checkbox label='Hot Water' />
                                             <Checkbox label='Attached bathroom' />
                                             <Checkbox label='Cooking' />
                                             <Checkbox label='Meals' />
                                             <Checkbox label='Non-Veg' />
                                             <Checkbox label='Warden' />
                                             <Checkbox label='Whashing Machine' />
                                             <Checkbox label='Cupboard' />
                                             <Checkbox label='Romm cleaning' />
                                             <Checkbox label='Parking' />
                                             </FormGroup>
                                             <div style={{'margin-left':'203px', 'margin-top': '-31px','margin-bottom':' -16px'}}>
                                             <Checkbox label='Add to compare' /> 
                                             </div>
                                             
       </div>
       
       </Grid.Column>
       <Grid.Column  width={4}>
    
    <div className="line3" ></div>
                <div className="compare">
                <div style={rating}>
                <h4 style={{ 'background-color': '#00b125',
                 'border-radius': '31px','text-color':'white',color:'white','padding':'9px'}}>4.3</h4>
                <span>*****</span><br/>
                {/* <span style={{}}>7 Reviews</span> */}
                </div>
                
                      <FormGroup className="side_line"> 
                         <h4 style={bt}>Grand Boys Pg</h4>
                         
                        <Radio name="radioGroup" inline >
                        gh
                              </Radio>{' '}
                              <Radio name="radioGroup" inline>
                              gf
                              </Radio>{' '}
                              <Radio name="radioGroup" inline>
                              2 views
                              </Radio>
                              
                          </FormGroup>
                         
                         
                          <div className="line3" ></div>
                          <div style={{"float":'right',    'margin-left':' 2px',
                          'margin-right': '-83px',
                          'margin-top': '5px'}}>
                          <span style={{'font-weight':'bold'}}>Deposit:</span><span style={bt}>1 Month Rent</span>
                          </div>
                           <FormGroup className="side_line">
                              <span style={bt}>4.2km</span> <span >From your location</span>
                                             </FormGroup>
                                             <div className="line3" ></div>
                                             <FormGroup>
                                             <Checkbox label='WIFI' />
                                             <Checkbox label='TV' />
                                             <Checkbox label='Camera' />
                                             <Checkbox label='A/C' />
                                             <Checkbox label='Hot Water' />
                                             <Checkbox label='Attached bathroom' />
                                             <Checkbox label='Cooking' />
                                             <Checkbox label='Meals' />
                                             <Checkbox label='Non-Veg' />
                                             <Checkbox label='Warden' />
                                             <Checkbox label='Whashing Machine' />
                                             <Checkbox label='Cupboard' />
                                             <Checkbox label='Romm cleaning' />
                                             <Checkbox label='Parking' />
                                             </FormGroup>
                                             <div style={{'margin-left':'203px', 'margin-top': '-31px','margin-bottom':' -16px'}}>
                                             <Checkbox label='Add to compare' /> 
                                             </div>
                                             
       </div>
       
       </Grid.Column>
       <Grid.Column  width={4}>

       </Grid.Column>
  </Grid>
    </div>
        )
    }
}
var tag = {
    position: 'absolute',
  right: 0,
  left: 0,
  'text-align': 'center'
    
  }
  var bt ={
    color:'#00b125'
  }
  var rating={
    'float':'right','padding':'9px','margin-left':'3px','padding-top':'0px', 
  }