<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* 
*
* Class: Category
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Category
* @category   Rest API
* @author     Vignessh A
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/
error_reporting(E_PARSE);
/**
 * CodeIgniter Rest Controller
 *
 * A fully RESTful server implementation for CodeIgniter using one library.
 *
 */
require APPPATH.'/libraries/REST_Controller.php';


class Category extends REST_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation'); // Library use to validate given input.
		$this->load->model('category_model');
		$this->form_validation->set_error_delimiters('', '');
		
	}
	
	// Function : Index 
	// Method : post
	
	public function index_post() {
		
		$input_data = json_decode(trim(file_get_contents('php://input')), true);
			
		$propertyName = get_object_vars($object);
		$post_key = array_keys($input_data);
		foreach($input_data as $key=>$val){
			$_POST[$key] = $val;
		}
			
		if(isset($_POST) != "") {

			$pre_key = array('category_name');
			
			// Empty key checking.
			$result=array_diff($pre_key,$post_key);
			if(!empty($result)) {
				$resc = "";
				foreach($result as $res){
					$resc .= $res.',';
				}
				$resc = substr($resc,0,-1) ;
	
				$result = Array ( "result" => "" );
				$msg = array("error_code" => "0", "msg" =>$resc, "result" => $result);
				$this->response($msg, 202);
	
			} else {
				$this->form_validation->set_rules('category_name', 'category_name', 'trim|required');
				
				if($this->form_validation->run() == FALSE)
				{
					$result = Array("result" => "");
					$msg = array("error_code" => "0", "msg" => "Error", "result" => validation_errors());
					$this->response($msg, 202);
	
				}
				else {
					$this->db->select('*');
					$this->db->from('product_category');
					$this->db->where('category_name',$_POST['category_name']);
					$query = $this->db->get();
					$results = $query->result_array();
					//print_r(sizeof($results));
					if(sizeof($results)>0)
					{
						$result = "Category Already Exist";
						$msg = array("error_code" => "0","msg" => "Error", "result" => $result);
						$this->response($msg, 202);
					} else {
						
						//upload file
						$config['upload_path'] = 'uploads/category/';
						$config['allowed_types'] = '*';
						$config['max_filename'] = '255';
						$config['encrypt_name'] = TRUE;
						$config['max_size'] = '1024'; //1 MB
						if (isset($_FILES['file']['name'])) {
							if (0 < $_FILES['file']['error']) {
								//echo 'Error during file upload' . $_FILES['file']['error'];
							} else {
								if (file_exists('uploads/category/' . $_FILES['file']['name'])) {
									//echo 'File already exists : uploads/category/' . $_FILES['file']['name'];
								} else {
									$this->load->library('upload', $config);
									if (!$this->upload->do_upload('file')) {
										//echo $this->upload->display_errors();
									} else {
										//echo 'File successfully uploaded : uploads/category/' . $_FILES['file']['name'];
										$imageurl = base_url().'uploads/category/'. $this->upload->data('file_name');
										$_POST['file'] = $imageurl;
										$result = $this->category_model->upload();
										$msg = array("error_code" => "1", "msg" => "Success", "result" => $result);
										$this->response($msg, 202);
									}
								}
							}
							
						} else {
							$result = $this->category_model->index();
							$msg = array("error_code" => "1", "msg" => "Success", "result" => $result);
							$this->response($msg, 202);
						}
		
					}
					
				}

			}
					
		}
		
		else { 		
			$result = "Invalid Data";
			$msg = array("error_code" => "0","msg" => "Error","result" => $result);
			$this->response($msg, 202);	
		}
		
	 }
}
