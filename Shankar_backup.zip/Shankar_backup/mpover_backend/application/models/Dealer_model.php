<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dealer_model extends CI_Model{
	public function __construct()
	{
		parent::__construct();		
		
    }
function lat_long_update($pincode,$lat,$lng,$reg_id){
		
		    $data = array(
        		  'latitude'  => $lat,
				  'longitude'  => $lng,
				  'zip' => $pincode	  
				  
    			);
		    $this->db->where('reg_id',$reg_id);
        	$this->db->update("register",$data);
        	$result = $this->db->insert_id();
		return $result;
	}
}