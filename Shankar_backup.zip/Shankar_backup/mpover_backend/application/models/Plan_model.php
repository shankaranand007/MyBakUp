<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Plan_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		
    }
    function index(){
        $data = array(            
            'amount' => $_POST['amount'],
            'description' => $_POST['description'], 
			'start_date' => $_POST['start_date'],
            'end_date' => $_POST['end_date'],
			'status' => $_POST['status']		
        );
        $this->db->insert('plan',$data);
        $result = $this->db->insert_id();
        return $result; 
    }
	
	
}