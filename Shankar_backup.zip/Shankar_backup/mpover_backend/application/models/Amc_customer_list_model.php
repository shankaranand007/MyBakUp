<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Amc_customer_list_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		
    }
    function index(){
        $this->db->select('*');
		$this->db->from('amc_register');
		$this->db->where('reg_id', $_POST['customerid']);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No Details Found";
			return $results;
		} else {
			
			$customer_id = $results[0]['customer_id'];
			$this->db->select('*');
			$this->db->from('customer');
			$this->db->where('cust_id', $customer_id);
			$query = $this->db->get();
			$customer_results = $query->result_array();
			if(sizeof($customer_results)==0) {
			$results = "No Details Found";
			return $results;
			} else {
			return $customer_results;
			}
		}    
    }
	
	
}