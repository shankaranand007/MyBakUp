import React, { Component } from 'react';
import './style.css';
// import logo from '../assets/logo.png';
import { Navbar,Nav,NavItem,NavDropdown,MenuItem,ButtonToolbar,DropdownButton,Grid,Row,Col} from 'react-bootstrap';

export default class Header2 extends Component {
    render() {
      return (
          <div>
        <Navbar  collapseOnSelect>
        <Navbar.Header>
          <Navbar.Brand>
            <img src="http://34.237.224.132/img/logo.png" style={divStyle} alt="logo"/>
          </Navbar.Brand>
          <Navbar.Toggle />
        </Navbar.Header>
        <Navbar.Collapse>
          {/* <Nav >
            <NavItem eventKey={1} href="#">
              Link
            </NavItem>
            <NavItem eventKey={2} href="#">
              Link
            </NavItem>
            <NavDropdown eventKey={3} title="Dropdown" id="basic-nav-dropdown">
              <MenuItem eventKey={3.1}>Action</MenuItem>
              <MenuItem eventKey={3.2}>Another action</MenuItem>
              <MenuItem eventKey={3.3}>Something else here</MenuItem>
              <MenuItem divider />
              <MenuItem eventKey={3.3}>Separated link</MenuItem>
            </NavDropdown>
          </Nav> */}
          <div class="container b2">
          <Grid>
          <Row className="show-grid">
                  <Col xs={1} md={2}>
                    {/* <code>&lt;{'Col xs={6} md={2}'} /">">&gt;</code> */}
                  
                  </Col>
                  <Col xs={11} md={6}>
                  <Col md={3} style={{"padding-right":"0px"}}>
                  <ButtonToolbar style={{"float":"right"}}>
                          <DropdownButton title="Select city" id="dropdown-size-medium">
                            <MenuItem eventKey="1">Chennai</MenuItem>
                            <MenuItem eventKey="2">Coimbathore</MenuItem>
                            <MenuItem eventKey="3">Bangaloru</MenuItem>
                            <MenuItem divider />
                            <MenuItem eventKey="4">Separated link</MenuItem>
                          </DropdownButton>
                          </ButtonToolbar>
                  </Col>
                 <Col md={8} style={{"padding-left":"0px"}}> <div className="form-group">
                          <input type="text" placeholder="Search" className="form-control fm" />
                          <button className="btsearch">*</button>
                          <button class="btn btlist" style={btn}>LIST</button>
                          </div>
                          </Col>
                         
                        
                    <br/>
                    {/* <div class="bt" style={{"float":"right"}}>
                        <label htmlFor="">Find in</label>
                    <button class="btn" style={btn}>LIST</button>
                    <button class="btn" style={btn}>MAP</button>
                    </div> */}
                  </Col>
                  <Col xsHidden md={2}>
                    {/* <code>&lt;{'Col xsHidden md={2}'} /">">&gt;</code> */}
                  </Col>
                </Row>
          </Grid>
    
        </div>
          <Nav pullRight >
            <NavItem eventKey={1} href="#">
              <b>ABOUT US</b>
            </NavItem>
            <NavItem eventKey={2} href="#">
              <b>MORE</b>
            </NavItem>
            <NavItem eventKey={3} href="#">
              <b>SIGN UP/LOGIN</b>
            </NavItem>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
      </div>
      );
    }
  }
  
  
  var divStyle = {
    height: "120px",
    position: "absolute"
  };
  var btn = {
    "background-color": "#00b125",
    "padding-right": "20px!important",
    "border-radius": "5px",
    "min-width": "85px",
    "max-height": "33px",
    "box-shadow": "inset -1px -1px 2px 0px black",
    color:"white"
    
  }