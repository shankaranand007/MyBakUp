<html>
<body>
<table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">
  <tbody>
    <tr>
      <td width="10" bgcolor="#28354d" style="width:10px;background:linear-gradient(to bottom,#28354d 0%,#28354d 89%);background-color:#28354d">&nbsp;</td>
      <td valign="middle" align="left" height="50" bgcolor="#28354d" style="background:linear-gradient(to bottom,#28354d 0%,#28354d 89%);background-color:#28354d;padding:0;margin:0"><a style="text-decoration:none;outline:none;color:#ffffff;font-size:13px" href="http://www.mostlikers.com" target="_blank">
          <img border="0" height="30" src="http://2.bp.blogspot.com/-ACPNUKELfPo/VAi1614YnwI/AAAAAAAABMk/yUEk1GIOuNQ/s1600/mos.png" alt="mostlikers.com" style="border:none" class="CToWUd">
        </a></td>
      <td valign="middle" align="right" height="50" bgcolor="#28354d" style="background:linear-gradient(to bottom,#28354d 0%,#28354d 89%);background-color:#28354d;padding:0;margin:0"><a style="text-decoration:none;outline:none;color:#ffffff;font-size:12px" href="http://mostlikers.2my4edge.com/" target="_blank">
        </a></td>
      <td width="10" bgcolor="#28354d" style="width:10px;background:linear-gradient(to bottom,#28354d 0%,#28354d 89%);background-color:#28354d">&nbsp;</td>
    </tr>
  </tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">
  <tbody>
    <tr>
      <td valign="top" align="center" width="300"><table border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#005387">
          <tbody>
            <tr>
              <td valign="middle" align="right" width="20%" height="35" style="border-bottom:solid 1px #003a5e;padding:0;color:#ffffff"><a style="text-decoration:none;outline:none;display:block" href="" target="_blank">
                </a></td>
              <td valign="middle" width="30%" align="left" height="35" style="border-bottom:solid 1px #003a5e;border-right:solid 1px #1a6592;padding:0 0 0 5px"><a style="text-decoration:none;outline:none;display:block" href="http://www.mostlikers.com/search/label/PHP?max-results=7" target="_blank">
                  <span style="font-size:11px;color:#99bacf;line-height:14px">PHP</span><br>
                </a></td>
              <td valign="middle" align="right" width="20%" height="35" style="border-bottom:solid 1px #003a5e;border-left:solid 1px #003a5e;padding:0;color:#ffffff"><a style="text-decoration:none;outline:none;display:block" href="http://www.mostlikers.com/search/label/PHP?max-results=7" target="_blank">
                </a></td>
              <td valign="middle" align="left" width="30%" height="35" style="border-bottom:solid 1px #003a5e;border-right:solid 1px #1a6592;padding:0 0 0 5px"><a style="text-decoration:none;outline:none;display:block" href="http://www.mostlikers.com/search/label/Web%20tricks?max-results=7" target="_blank">
                  <span style="font-size:11px;color:#99bacf;line-height:14px">WEB TRICKS</span>
                </a></td>
            </tr>
          </tbody>
        </table></td>
      <td valign="top" align="center" width="300"><table border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#005387">
          <tbody>
            <tr>
              <td valign="middle" align="right" width="20%" height="35" style="border-bottom:solid 1px #003a5e;border-left:solid 1px #003a5e;padding:0;color:#ffffff"><a style="text-decoration:none;outline:none;display:block" href="http://mostlikers.2my4edge.com/" target="_blank">
                </a></td>
              <td valign="middle" align="left" width="30%" height="35" style="border-bottom:solid 1px #003a5e;border-right:solid 1px #1a6592;padding:0 0 0 5px"><a style="text-decoration:none;outline:none;display:block" href="http://www.mostlikers.com/search/label/Mysqli?max-results=7" target="_blank">
                  <span style="font-size:11px;color:#99bacf;white-space:nowrap;line-height:14px">MYSQLI</span>
                </a></td>
              <td valign="middle" align="right" width="20%" height="35" style="border-bottom:solid 1px #003a5e;border-left:solid 1px #003a5e;padding:0;color:#ffffff"><a style="text-decoration:none;outline:none;display:block" href="" target="_blank">
                </a></td>
              <td valign="middle" align="left" width="30%" height="35" style="border-bottom:solid 1px #003a5e;padding:0 0 0 5px"><a style="text-decoration:none;outline:none;display:block" href="http://mostlikers.2my4edge.com/" target="_blank">
                  <span style="font-size:11px;color:#99bacf;line-height:14px">DEMOS</span>
                </a></td>
            </tr>
          </tbody>
        </table></td>
    </tr>
  </tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">
  <tbody>
    <tr>
      <td align="left" valign="top" style="color:#2c2c2c;display:block;line-height:20px;font-weight:300;margin:0 auto;clear:both;border-bottom:2px dashed #ccc;background-color:#f9f9f9;padding:20px" bgcolor="#F9F9F9"><p style="padding:0;margin:0;font-size:16px;font-weight:bold;font-size:13px"> Hi <?=@$firstname;?>
        </p>
        <br>
        <p style="padding:0;margin:0;color:#565656;line-height:22px;font-size:13px"> Thanks for visiting our site
          <a href="http://www.mostlikers.com"> www.mostlikers.com,</a>
          This is customised Email template. i hope this tutorial is really helpful and useful to you. </p></td>
    </tr>
  </tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">
  <tbody>
    <tr>
      <td valign="top" align="center" width="300" style="background-color:#f9f9f9"><br>
        <table width="100%" cellspacing="0" cellpadding="0">
          <tbody>
            <tr>
              <td valign="top" align="left" style="padding:0 10px 15px 20px;margin:0;border-right:dashed 1px #b3b3b3"><a href="http://www.mostlikers.com" style="text-decoration:none;" >
                  <p style="padding:0;margin:0 0 7px 0;font-size:16px;color:#565656">TUTORIALS</p>
                  <p style="padding:0;margin:0;font-size:11px;color:#565656;line-height:20px"> Here in www.mostlikers.com has more Tutorials regarding web related things. </p>
                </a></td>
            </tr>
          </tbody>
        </table></td>
      <td valign="top" align="center" width="300" style="background-color:#f9f9f9"><br>
        <table width="100%" cellspacing="0" cellpadding="0">
          <tbody>
            <tr>
              <td valign="top" align="left" style="padding:0 10px 15px 20px;margin:0"><a href="http://mostlikers.2my4edge.com/" style="text-decoration:none;" >
                  <p style="padding:0;margin:0 0 7px 0;font-size:16px;color:#565656">DEMOS</p>
                  <p style="padding:0;margin:0;font-size:11px;color:#565656;line-height:20px"> And in DEMOS, we are showing everthing with demo examples repect to the tutorials.</p>
                </a></td>
            </tr>
          </tbody>
        </table></td>
    </tr>
  </tbody>
</table>
<table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border:solid 1px #e6e6e6;border-top:none">
  <tbody>
    <tr>
      <td valign="top" align="center" style="text-align:center;background-color:#f9f9f9;display:block;margin:0 auto;clear:both;padding:15px 40px" bgcolor=""><p style="padding:0;margin:0 0 7px 0">
          <a title="mostlikers.com" style="text-decoration:none;color:#565656" href="http://www.mostlikers.com" target="_blank"><span style="color:#565656;font-size:13px">www.mostlikers.com</span></a>
        </p>
        <p style="padding:10px 0 0 0;margin:0;border-top:solid 1px #cccccc;font-size:11px;color:#565656">
          <a href="http://feeds.feedburner.com/mostlikers">SUBSCRIBE IN FEED</a>
          &nbsp; | &nbsp;
          <a href="https://www.facebook.com/Mostlikers">FACEBOOK</a>
          &nbsp; | &nbsp;
          <a href="https://plus.google.com/u/0/110408905103915967450/">GOOGLE+</a>
          &nbsp; | &nbsp;
          <a href="https://twitter.com/karthickmuthu7">TWITTER</a>
        </p></td>
    </tr>
  </tbody>
</table>
</body>
</html>