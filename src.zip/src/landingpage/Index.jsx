import React, { Component } from 'react';
import './main.css';
// import logo from '../assets/logo.png';
// import { Navbar,Nav,NavItem,NavDropdown,MenuItem} from 'react-bootstrap';
// import RangeSlider from 'react-dual-rangeslider';
import Header1 from '../common/Header1.jsx';
import { Grid,Row,Col,ButtonToolbar,DropdownButton,MenuItem,FormGroup,Checkbox,Radio,Button} from 'react-bootstrap';

class Index extends Component {
    render() {
      return (
        <div>
            <Header1 />
            <Grid>
                <Row className="show-grid">
                  <Col xs={1} md={3}>
                    {/* <code>&lt;{'Col xs={6} md={2}'} /">">&gt;</code> */}
                  </Col>
                  <Col xs={11} md={6}>
                    <div class="bbb2">
                      <h3>Helping You Get that PG that's will be</h3>
                      <h1 style={headstyle}><b>your home away from home</b></h1>
                      <div className="line"></div>

                        <ButtonToolbar>
                          <DropdownButton title="Select city" id="dropdown-size-medium">
                            <MenuItem eventKey="1">Chennai</MenuItem>
                            <MenuItem eventKey="2">Coimbathore</MenuItem>
                            <MenuItem eventKey="3">Bangaloru</MenuItem>
                            <MenuItem divider />
                            <MenuItem eventKey="4">Separated link</MenuItem>
                          </DropdownButton>
                          <div className="form-group">
                          <input type="text" placeholder="Search" className="form-control" />
                          <button>*</button>
                          </div>
                        </ButtonToolbar>
                          {/* <br/> */}
                        <form class="form_box">
                        <FormGroup>
                          <label htmlFor="">Gender &nbsp;:&nbsp;</label>
                        <Radio name="radioGroup" inline >
                                Male
                              </Radio>{' '}
                              <Radio name="radioGroup" inline>
                                Female
                              </Radio>{' '}
                              <Radio name="radioGroup" inline>
                                Others
                              </Radio>
                        </FormGroup>
                        <FormGroup>
                        <label htmlFor="">Budget &nbsp;:&nbsp;&nbsp;&nbsp;<span style={headstyle}> 5000</span>&nbsp;$/Month</label>
                        <div><input type="range"  /></div>
                           {/* <label htmlFor="">Budget &nbsp;:&nbsp;</label>
                            <RangeSlider
                              min={0}
                              max={1000}
                              minRange={10}
                              // onChange={(state)=>{
                              //     console.log('react-dual-rangeslider max: ', state.max);
                              //     console.log('react-dual-rangeslider min: ', state.min);
                              // }}
                              step={1}
                          /> */}
                        
                        </FormGroup>
                        {/* <br/> */}
                        <FormGroup>
                          
                        <label htmlFor="">Sharing &nbsp;:&nbsp;</label>
                              <Radio name="radioGroup" inline>
                              One
                              </Radio>{' '}
                              <Radio name="radioGroup" inline>
                                Two
                              </Radio>{' '}
                              <Radio name="radioGroup" inline>
                                Three
                              </Radio>
                              <Radio name="radioGroup" inline>
                                Four
                              </Radio>
                        </FormGroup>
                        <div className="line2" ></div>
                        </form>
                    </div>
                    <br/>
                    <div class="bt" style={{"float":"right"}}>
                      {/* <FormGroup> */}
                        <label htmlFor="">Find in</label>
                    <button class="btn" style={btn}>LIST</button>
                    <button class="btn" style={btn}>MAP</button>
                    {/* </FormGroup> */}
                    </div>
                  </Col>
                  <Col xsHidden md={1}>
                    {/* <code>&lt;{'Col xsHidden md={2}'} /">">&gt;</code> */}
                  </Col>
                </Row>
              </Grid>
                 
                 {/* <div className="line"></div> */}
            
        </div>
        
      );
    }
  }
  
  export default Index;

 var headstyle = {
   color:"#00b125",
   
 }
 var btn = {
  "background-color": "#00b125",
  "padding-right": "20px!important",
  "border-radius": "5px",
  "min-width": "85px",
  "max-height": "32px",
  "box-shadow": "inset -1px -1px 2px 0px black",
  color:"white"
  
}
var tag = {
  position: 'absolute',
right: 0,
left: 0,
'text-align': 'center'
  
}