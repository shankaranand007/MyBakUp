<?php if(! defined('BASEPATH')) exit('No direct script access allowed');
/* 
*
* Class: Profile
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Profile
* @category   Rest API
* @author     Aravinthakumar S
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/
require APPPATH.'libraries/REST_Controller.php';

class Profile extends REST_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');	
		$this->form_validation->set_error_delimiters('','');
	}	
	
	public function profileview_post()
	{
		$this->db->select('*');
		$this->db->from('customer');
		$this->db->where('status',1);		
		$this->db->where('cust_id', $_POST['cust_id']);
		$query=$this->db->get();
		$resp=$query->result_array();
		$msg=array("error"=>1,"msg"=>"success","result"=>$resp);
		$this->response($msg,202);
	}
	
	public function profileedit_post()
	{
		
		$data=array(		
		'first_name' => $_POST['first_name'],
		'last_name' => $_POST['last_name'],
		'name'  => $_POST['first_name'].$_POST['last_name'],		
		'email'     => $_POST['email'],
        'address' => $_POST['address'], 
		'city' => $_POST['city'], 
        'state'  => $_POST['state'],        
		'mobile'  => $_POST['mobile']
		);
		$this->db->where('cust_id',$_POST['cust_id']);
		$this->db->where('status',1);
		$this->db->update('customer',$data);		
		$affected=$this->db->affected_rows();
		$msg=array("error"=>1,"msg"=>"Success","Results"=>$affected);
		$this->response($msg,202);
		
	}
	
	
	
	
}
