<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* 
*
* Class: Email
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Email
* @category   Rest API
* @author     Vignessh A
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/
error_reporting(0);
//require APPPATH.'/libraries/REST_Controller.php';


class Email extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation'); // Library use to validate given input.
		$this->load->library('email');
		$this->form_validation->set_error_delimiters('', '');
		
	}
	
	// Function : Index 
	// Method : post
	
	public function index() {
		
		//SMTP & mail configuration
		$config = array(
			'protocol' => 'smtp',
			'smtp_host' => 'ssl://smtp.googlemail.com',
			'smtp_port' => 465,
			'smtp_user' => 'viki.thecoolestbuddy4@gmail.com',
			'smtp_pass' => '9944221407',
			'mailtype'  => 'html',
			'charset'   => 'utf-8'
		);
		$this->email->initialize($config);
		$this->email->set_mailtype("html");
		$this->email->set_newline("\r\n");
		
		//Email content
		$htmlContent = '<h1>Sending email via SMTP server</h1>';
		$htmlContent .= '<p>This email has sent via SMTP server from CodeIgniter application.</p>';
		
		$this->email->to('avignessh08@gmail.com');
		$this->email->from('viki.thecoolestbuddy4@gmail.com','MyWebsite');
		$this->email->subject('How to send email via SMTP server in CodeIgniter');
		$this->email->message($htmlContent);
		
		//Send email
		$this->email->send();
		
		$msg = array("error_code" => "1", "msg" => "Success");
		$this->response($msg, 202);
		
	 }	
}
