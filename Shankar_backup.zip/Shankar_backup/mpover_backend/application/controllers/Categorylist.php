<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* 
*
* Class: Login
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Login
* @category   Rest API
* @author     Vignessh A
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/
error_reporting(0);
require APPPATH.'/libraries/REST_Controller.php';


class Categorylist extends REST_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation'); // Library use to validate given input.
		$this->load->model('categorylist_model');
		$this->form_validation->set_error_delimiters('', '');
		
	}
	
	// Function : Index 
	// Method : post
	
	public function index_post() {
		
		$result = $this->categorylist_model->index();
		$msg = array("error_code" => "1", "msg" => "Success", "result" => $result);
		$this->response($msg, 202);
		
	}	
}
