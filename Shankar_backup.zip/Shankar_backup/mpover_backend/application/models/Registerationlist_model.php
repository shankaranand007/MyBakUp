<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Registerationlist_model extends CI_Model{
	public function __construct()
	{
		parent::__construct();
		
		
    }
    function index(){
		$result['registration'] = $this->registration();
		$result['vehicle_type'] = $this->vehicle_type();
		$result['tyre_size'] = $this->tyre_size();
		$result['brand'] = $this->brand();
		$result['biasradial'] = $this->biasradial();
		$result['prload'] = $this->prload();
		$result['speed_rating'] = $this->speed_rating();
		$result['vehicle_brand'] = $this->vehicle_brand();
		$result['registered_owner'] = $this->registered_owner();
		$result['fitment_position'] = $this->fitment_position();
		
		return $result;
    }
	
	function registration() {
		$this->db->select('name');
		$this->db->from('registration');
		$this->db->where('status', 1);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No registration Found";
			return $results;
		} else {	
			return $results;
		}        
	}
	
	function vehicle_type() {
		$this->db->select('name');
		$this->db->from('vehicle');
		$this->db->where('status', 1);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No Vehicle Found";
			return $results;
		} else {	
			return $results;
		}        
	}
	
	function tyre_size() {
		$this->db->select('size');
		$this->db->from('tyresize');
		$this->db->where('status', 1);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No Tyre Size Found";
			return $results;
		} else {	
			return $results;
		}        
	}
	
	function brand() {
		$this->db->select('brand_name');
		$this->db->from('brand');
		$this->db->where('status', 1);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No Brand Found";
			return $results;
		} else {	
			return $results;
		}        
	}
	
	function biasradial() {
		$this->db->select('name');
		$this->db->from('biasradial');
		$this->db->where('status', 1);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No Bias Radial Found";
			return $results;
		} else {	
			return $results;
		} 
	}
	
	function prload() {
		$this->db->select('prload_intex');
		$this->db->from('prload');
		$this->db->where('status', 1);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No PR Load Found";
			return $results;
		} else {	
			return $results;
		} 
	}
	
	function speed_rating() {
		$this->db->select('name');
		$this->db->from('speed_rating');
		$this->db->where('status', 1);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No Speed Rating Found";
			return $results;
		} else {	
			return $results;
		} 
	}
	
	function vehicle_brand() {
		$this->db->select('name');
		$this->db->from('vehicle_brand');
		$this->db->where('status', 1);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No Vehicle Brand Found";
			return $results;
		} else {	
			return $results;
		} 
	}
	
	function registered_owner() {
		$this->db->select('name');
		$this->db->from('registered_owner');
		$this->db->where('status', 1);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No Registered Owner Found";
			return $results;
		} else {	
			return $results;
		} 
	}
	
	function fitment_position() {
		$this->db->select('fitment_position');
		$this->db->from('fitment_position');
		$this->db->where('status', 1);
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No Fitment Position Found";
			return $results;
		} else {	
			return $results;
		} 
	}

}