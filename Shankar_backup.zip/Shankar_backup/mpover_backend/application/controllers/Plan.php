<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* 
*
* Class: Api_Plan
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Api_Plan
* @category   Rest API
* @author     Vishnuraj KN
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/

require APPPATH.'/libraries/REST_Controller.php';


class Plan extends REST_Controller 
{
	
	public function __construct()
	{
		parent::__construct();		
		$this->load->model('Plan_model');		
	}
	
	public function index_post()
	{
		if(isset($_POST)!= "")
		{
			
			$post_key = array_keys($_POST);			
			$pre_key = array('amount','description','start_date','end_date','status');
			$result=array_diff($pre_key,$post_key);			
			if(!empty($result))
			{
				$res="";
				foreach($result as $resp)
				{
					$res.=$resp;
				}
				$res=substr($res,0,-1);
				$result=array("result"=>"");
				$msg= array("error_code"=>"0","msg"=>$res,"result"=>$result);
				$this->response($msg,202);
			}
			else
			{
				$result = $this->Plan_model->index();
				$msg=array("error_code"=>"1","msg"=>"Success","result"=>$result);
				$this->response($msg,202);
			}
		}
		else
		{
			$result = "invalid";
	 		$msg = array("error_code" => "1","msg" =>"fail","result" => $result);
	 		$this->response($result, 201);
		}
		
	}
	
	
	
}
?>