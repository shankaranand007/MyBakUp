<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* 
*
* Class: Api_Brand
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Api_Brand
* @category   Rest API
* @author     Aravinthakumar S
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/

require APPPATH.'/libraries/REST_Controller.php';

class Brand extends REST_Controller 
{
	
	public function __construct()
	{
		parent::__construct();		
		$this->load->model('Brand_model');		
	}
	
	public function index_post()
	{
		if(isset($_POST)!= "")
		{
			
			$post_key = array_keys($_POST);			
			$pre_key = array('brand_name','status');
			$result=array_diff($pre_key,$post_key);			
			if(!empty($result))
			{
				$res="";
				foreach($result as $resp)
				{
					$res.=$resp;
				}
				$res=substr($res,0,-1);
				$result=array("result"=>"");
				$msg= array("error_code"=>"0","msg"=>$res,"result"=>$result);
				$this->response($msg,202);
			}
			else
			{
				$result = $this->Brand_model->index();
				$msg=array("error_code"=>"1","msg"=>"Success","result"=>$result);
				$this->response($msg,202);
			}
		}
		else
		{
			$result = "invalid";
	 		$msg = array("error_code" => "1","msg" =>"fail","result" => $result);
	 		$this->response($result, 201);
		}
		
	}
	
	function brandview_post()
	 {	 	
	 	
		$this->db->select('*');
		$this->db->from('vehicle_brand');
		$this->db->where('status',1);
		$query = $this->db->get();
		$afftected = $query->result_array();	 		
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftected);
	    $this->response($msg,202);
	 }
	 function brandviewedit_post()
	 {	 	
	 	
		$this->db->select('*');
		$this->db->from('vehicle_brand');
		$this->db->where('brand_id',$_POST['brand_id']);
		$query = $this->db->get();
		$afftected = $query->result_array();	 		
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftected);
	    $this->response($msg,202);
	 }
	 
	
	function brandedit_post()
	 {
	 	$data = array(
            'brand_name' =>$_POST['brand_name'],
            'status'  =>$_POST['status']           
        );
	 	$this->db->where("brand_id",$_POST['brand_id']);
	 	$this->db->update("vehicle_brand",$data);
	 	$afftectedRows = $this->db->affected_rows();
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftectedRows);
	    $this->response($msg,202);
	 }
	
	function branddelete_post()
	{
		$this->db->where("brand_id",$_POST['brand_id']);			
		$this->db->delete("vehicle_brand");
		$affectedRows=$this->db->affected_rows();
		$msg=array("error"=>1,"msg"=>"Success","result"=>$affectedRows);
		$this->response($msg,202);
	}
	
	function newbrandmodal_post()
	{
		if(isset($_POST)!= "")
		{
			
			$post_key = array_keys($_POST);			
			$pre_key = array('modal_name','modal_brand_id','modal_description','tyre_size','modal_status');
			$result=array_diff($pre_key,$post_key);			
			if(!empty($result))
			{
				$res="";
				foreach($result as $resp)
				{
					$res.=$resp;
				}
				$res=substr($res,0,-1);
				$result=array("result"=>"");
				$msg= array("error_code"=>"0","msg"=>$res,"result"=>$result);
				$this->response($msg,202);
			}
			else
			{
				$result = $this->Brand_model->newbrandmodal();
				$msg=array("error_code"=>"1","msg"=>"Success","result"=>$result);
				$this->response($msg,202);
			}
		}
		else
		{
			$result = "invalid";
	 		$msg = array("error_code" => "1","msg" =>"fail","result" => $result);
	 		$this->response($result, 201);
		}
	}
	
	function brandmodaledit_post()
	 {
	 	$data = array(
            'modal_name' =>$_POST['modal_name'],
            'modal_brand_id' =>$_POST['modal_brand_id'],
            'tyre_size' =>$_POST['tyre_size'],
            'modal_description' =>$_POST['modal_description'],
            'modal_status' =>$_POST['modal_status']	);
	 	$this->db->where("modal_id",$_POST['modal_id']);
	 	$this->db->update("brand_modal",$data);
	 	$afftectedRows = $this->db->affected_rows();
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftectedRows);
	    $this->response($msg,202);
	 }
	
	function brandmodaldelete_post()
	{
		$this->db->where("modal_id",$_POST['modal_id']);			
		$this->db->delete("brand_modal");
		$affectedRows=$this->db->affected_rows();
		$msg=array("error"=>1,"msg"=>"Success","result"=>$affectedRows);
		$this->response($msg,202);
	}

	function brandmodalview_post()
	 {	 	
	 	
		$this->db->select('*');
		$this->db->from('brand_modal');
		$this->db->where('modal_status',1);
		$query = $this->db->get();
		$afftected = $query->result_array();	 		
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftected);
	    $this->response($msg,202);
	 }
	 function brandmodalviewedit_post()
	 {	 	
	 	
		$this->db->select('*');
		$this->db->from('brand_modal');
		$this->db->where('modal_id',$_POST['modal_id']);
		$query = $this->db->get();
		$afftectedrows = $query->result_array();	 		
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftectedrows);
	    $this->response($msg,202);
	 }
	
}
?>