<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* 
*
* Class: Tyre Registeration
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Tyre Registeration
* @category   Rest API
* @author     Vignessh A
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/
error_reporting(E_PARSE);
/**
 * CodeIgniter Rest Controller
 *
 * A fully RESTful server implementation for CodeIgniter using one library.
 *
 */
require APPPATH.'/libraries/REST_Controller.php';


class Tyreregisteration extends REST_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation'); // Library use to validate given input.
		$this->load->model('tyreregisteration_model');
		$this->form_validation->set_error_delimiters('', '');
		
	}
	
	// Function : Index 
	// Method : post
	
	public function index_post() {
		
		$input_data = json_decode(trim(file_get_contents('php://input')), true);
			
		$propertyName = get_object_vars($object);
		$post_key = array_keys($input_data);
		foreach($input_data as $key=>$val){
			$_POST[$key] = $val;
		}
			
		if(isset($_POST) != "") {

			$pre_key = array('registration', 'type_of_vehicle', 'tyre_size', 'description_brand', 'bias_radial', 'pattern_design', 'pr_loadindex', 'speed_rating', 'description_tyre_sno', 'nsd_at_twi_mm', 'dealer_fleet_registration_code', 'tyre_band_ply', 'upload_tyre_sno', 'invoice_photo', 'vehicle_brand', 'vehicle_regno', 'nameof_registered_owner', 'fitment_position', 'mobile_country_code', 'emailid', 'nominee_name_relationship', 'running_wheels', 'fitment_photo', 'fullvehicle_photo');
			
			// Empty key checking.
			$result=array_diff($pre_key,$post_key);
			if(!empty($result)) {
				$resc = "";
				foreach($result as $res){
					$resc .= $res.',';
				}
				$resc = substr($resc,0,-1) ;
	
				$result = Array ( "result" => "" );
				$msg = array("error_code" => "0", "msg" =>$resc, "result" => $result);
				$this->response($msg, 202);
	
			} else {
				$this->form_validation->set_rules('registration', 'Registeration', 'trim|required');
				$this->form_validation->set_rules('type_of_vehicle', 'Type of Vehicle', 'trim|required');
				$this->form_validation->set_rules('description_brand', 'Brand', 'trim|required');
				$this->form_validation->set_rules('bias_radial', 'Bias / Radial', 'trim|required');
				$this->form_validation->set_rules('pattern_design', 'Pattern /Design', 'trim|required');
				$this->form_validation->set_rules('pr_loadindex', 'PR / Load index', 'trim|required');
				$this->form_validation->set_rules('speed_rating', 'Speed rating', 'trim|required');
				$this->form_validation->set_rules('dealer_fleet_registration_code', 'Dealer / Fleet Registration code', 'trim|required');
				$this->form_validation->set_rules('tyre_band_ply', 'Tyre Band ply', 'trim|xss_clean');
				$this->form_validation->set_rules('upload_tyre_sno', 'Tyre S.No', 'trim|xss_clean');
				$this->form_validation->set_rules('invoice_photo', 'Invoice Photo', 'trim|xss_clean');
				$this->form_validation->set_rules('vehicle_brand', 'Brand', 'trim|required');
				$this->form_validation->set_rules('vehicle_regno', 'Vehicle Reg no', 'trim|required');
				$this->form_validation->set_rules('nameof_registered_owner', 'Name of Registered Owner', 'trim|required');
				$this->form_validation->set_rules('fitment_position', 'Fitment position', 'trim|required');
				$this->form_validation->set_rules('mobile_country_code', 'Mobile Number with Country code', 'trim|required');
				$this->form_validation->set_rules('nominee_name_relationship', 'Nominee Name & relationship', 'trim|required');
				$this->form_validation->set_rules('running_wheels', 'Running wheels', 'trim|required');
				$this->form_validation->set_rules('fitment_photo', 'Fitment position photo with Vehicle', 'trim|xss_clean');
				
				if($this->form_validation->run() == FALSE)
				{
					$result = Array("result" => "");
					$msg = array("error_code" => "1", "msg" => "Error", "result" => validation_errors());
					$this->response($msg, 202);
	
				}
				else {
						
					//upload file
					$config['upload_path'] = 'uploads/tyredetails/';
					$config['allowed_types'] = '*';
					$config['max_filename'] = '255';
					$config['encrypt_name'] = TRUE;
					$config['max_size'] = '1024'; //1 MB
					// Tyre Brand Upload
					if (isset($_FILES['tyre_band_ply']['name'])) {
						if (0 < $_FILES['tyre_band_ply']['error']) {
						} else {
							if (file_exists('uploads/tyredetails/' . $_FILES['tyre_band_ply']['name'])) {
								//echo 'File already exists : uploads/tyredetails/' . $_FILES['tyre_band_ply']['name'];
							} else {
								$this->load->library('upload', $config);
								if (!$this->upload->do_upload('tyre_band_ply')) {
									//echo $this->upload->display_errors();
								} else {
									//echo 'File successfully uploaded : uploads/tyredetails/' . $_FILES['tyre_band_ply']['name'];
									$tyre_band_ply = base_url().'uploads/tyredetails/'. $this->upload->data('file_name');
									$_POST['tyre_band_ply'] = $tyre_band_ply;
								}
							}
						}
						
					} else {
						$msg = array("error_code" => "1", "msg" => "Error", "result" => "Tyre Band Ply is required");
						$this->response($msg, 202);
						die;
					}
					
					//Tyre S.no Upload
					if (isset($_FILES['upload_tyre_sno']['name'])) {
						if (0 < $_FILES['upload_tyre_sno']['error']) {
						} else {
							if (file_exists('uploads/tyredetails/' . $_FILES['upload_tyre_sno']['name'])) {
								//echo 'File already exists : uploads/tyredetails/' . $_FILES['upload_tyre_sno']['name'];
							} else {
								$this->load->library('upload', $config);
								if (!$this->upload->do_upload('upload_tyre_sno')) {
									//echo $this->upload->display_errors();
								} else {
									//echo 'File successfully uploaded : uploads/tyredetails/' . $_FILES['upload_tyre_sno']['name'];
									$upload_tyre_sno = base_url().'uploads/tyredetails/'. $this->upload->data('file_name');
									$_POST['upload_tyre_sno'] = $upload_tyre_sno;
								}
							}
						}
						
					} else {
						$msg = array("error_code" => "1", "msg" => "Error", "result" => "Tyre S.No is required");
						$this->response($msg, 202);
						die;
					}
					
					//invoice_photo Upload
					if (isset($_FILES['invoice_photo']['name'])) {
						if (0 < $_FILES['invoice_photo']['error']) {
						} else {
							if (file_exists('uploads/tyredetails/' . $_FILES['invoice_photo']['name'])) {
								//echo 'File already exists : uploads/tyredetails/' . $_FILES['invoice_photo']['name'];
							} else {
								$this->load->library('upload', $config);
								if (!$this->upload->do_upload('invoice_photo')) {
									//echo $this->upload->display_errors();
								} else {
									//echo 'File successfully uploaded : uploads/tyredetails/' . $_FILES['invoice_photo']['name'];
									$invoice_photo = base_url().'uploads/tyredetails/'. $this->upload->data('file_name');
									$_POST['invoice_photo'] = $invoice_photo;
								}
							}
						}
						
					} else {
						$msg = array("error_code" => "1", "msg" => "Error", "result" => "Invoice Photo is required");
						$this->response($msg, 202);
						die;
					}
					
					//fitment_photo Upload
					if (isset($_FILES['fitment_photo']['name'])) {
						if (0 < $_FILES['fitment_photo']['error']) {
						} else {
							if (file_exists('uploads/tyredetails/' . $_FILES['fitment_photo']['name'])) {
								//echo 'File already exists : uploads/tyredetails/' . $_FILES['fitment_photo']['name'];
							} else {
								$this->load->library('upload', $config);
								if (!$this->upload->do_upload('fitment_photo')) {
									//echo $this->upload->display_errors();
								} else {
									//echo 'File successfully uploaded : uploads/tyredetails/' . $_FILES['fitment_photo']['name'];
									$fitment_photo = base_url().'uploads/tyredetails/'. $this->upload->data('file_name');
									$_POST['fitment_photo'] = $fitment_photo;
								}
							}
						}
						
					} else {
						$msg = array("error_code" => "1", "msg" => "Error", "result" => "Fitment position photo with Vehicle  is required");
						$this->response($msg, 202);
						die;
					}
					
					//fullvehicle_photo Upload
					if (isset($_FILES['fullvehicle_photo']['name'])) {
						if (0 < $_FILES['fullvehicle_photo']['error']) {
						} else {
							if (file_exists('uploads/tyredetails/' . $_FILES['fullvehicle_photo']['name'])) {
								//echo 'File already exists : uploads/tyredetails/' . $_FILES['fullvehicle_photo']['name'];
							} else {
								$this->load->library('upload', $config);
								if (!$this->upload->do_upload('fullvehicle_photo')) {
									//echo $this->upload->display_errors();
								} else {
									//echo 'File successfully uploaded : uploads/tyredetails/' . $_FILES['fullvehicle_photo']['name'];
									$fullvehicle_photo = base_url().'uploads/tyredetails/'. $this->upload->data('file_name');
									$_POST['fullvehicle_photo'] = $fullvehicle_photo;
								}
							}
						}
						
					} else {
						$_POST['fullvehicle_photo'] = '';
					}
					
					$result = $this->tyreregisteration_model->index();
					$msg = array("error_code" => "0", "msg" => "Success", "result" => $result);
					$this->response($msg, 202);
				}

			}
					
		}
		
		else { 		
			$result = "Invalid Data";
			$msg = array("error_code" => "1","msg" => "Error","result" => $result);
			$this->response($msg, 202);	
		}
		
	 }
}
