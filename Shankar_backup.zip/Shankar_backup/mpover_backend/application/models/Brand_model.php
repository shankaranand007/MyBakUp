<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Brand_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		
    }
    function index(){
        $data = array(            
            'brand_name' => $_POST['brand_name'],
            'status' => $_POST['status']            
        );
        $this->db->insert('vehicle_brand',$data);
        $result = $this->db->insert_id();
        return $result; 
    }
	
	function newbrandmodal(){
        $data = array(        
            'modal_name' => $_POST['modal_name'],
            'modal_brand_id' => $_POST['modal_brand_id'],
			'tyre_size' =>$_POST['tyre_size'],
            'modal_description' => $_POST['modal_description'],
            'modal_status' => $_POST['modal_status']               
        );
        $this->db->insert('brand_modal',$data);
        $result = $this->db->insert_id();
        return $result; 
    }

}