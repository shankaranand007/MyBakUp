<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* 
*
* Class: Api_Pr
*
* Index Function for this controller is used to save user given data into database.
* @package    CodeIgniter
* @subpackage Api_Pr
* @category   Rest API
* @author     Aravinthakumar S
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/

require APPPATH.'/libraries/REST_Controller.php';

class Pr extends REST_Controller 
{
	
	public function __construct()
	{
		parent::__construct();		
		$this->load->model('Pr_model');		
	}
	
	public function index_post()
	{
		if(isset($_POST)!= "")
		{
			
			$post_key = array_keys($_POST);			
			$pre_key = array('pr_load_index');
			$result=array_diff($pre_key,$post_key);			
			if(!empty($result))
			{
				$res="";
				foreach($result as $resp)
				{
					$res.=$resp;
				}
				$res=substr($res,0,-1);
				$result=array("result"=>"");
				$msg= array("error_code"=>"0","msg"=>$res,"result"=>$result);
				$this->response($msg,202);
			}
			else
			{
				$result = $this->Pr_model->index();
				$msg=array("error_code"=>"1","msg"=>"Success","result"=>$result);
				$this->response($msg,202);
			}
		}
		else
		{
			$result = "invalid";
	 		$msg = array("error_code" => "1","msg" =>"fail","result" => $result);
	 		$this->response($result, 201);
		}
		
	}
	
	function prview_post()
	 {	 	
	 	
		$this->db->select('*');
		$this->db->from('pr_tyre');		
		$query = $this->db->get();
		$afftected = $query->result_array();	 		
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftected);
	    $this->response($msg,202);
	 }
	 function prviewedit_post()
	 {	 	
	 	
		$this->db->select('*');
		$this->db->from('pr_tyre');
		$this->db->where('pr_id',$_POST['pr_id']);
		$query = $this->db->get();
		$afftected = $query->result_array();	 		
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftected);
	    $this->response($msg,202);
	 }
	 
	
	function predit_post()
	 {
	 	$data = array(
            'pr_load_index' =>$_POST['pr_load_index']                      
        );
	 	$this->db->where("pr_id",$_POST['pr_id']);
	 	$this->db->update("pr_tyre",$data);
	 	$afftectedRows = $this->db->affected_rows();
	 	$msg = array("error"=>1,"msg"=>"success","results"=>$afftectedRows);
	    $this->response($msg,202);
	 }
	
	function prdelete_post()
	{
		$this->db->where("pr_id",$_POST['pr_id']);			
		$this->db->delete("pr_tyre");
		$affectedRows=$this->db->affected_rows();
		$msg=array("error"=>1,"msg"=>"Success","result"=>$affectedRows);
		$this->response($msg,202);
	}
}
	?>