<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pr_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		
    }
    function index(){
        $data = array(            
            'pr_load_index' => $_POST['pr_load_index']                       
        );
        $this->db->insert('pr_tyre',$data);
        $result = $this->db->insert_id();
        return $result; 
    }
}
?>