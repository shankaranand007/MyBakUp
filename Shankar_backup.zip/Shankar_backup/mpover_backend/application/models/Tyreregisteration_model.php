<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tyreregisteration_model extends CI_Model{
	public function __construct()
	{
		parent::__construct();
    }
	
    function index(){
        $data = array(
			tyre_registraion_id => $_POST['tyre_registraion_id'],
			registration => $_POST['registration'],
			type_of_vehicle => $_POST['type_of_vehicle'],
			tyre_size => $_POST['tyre_size'],
			description_brand => $_POST['description_brand'],
			bias_radial => $_POST['bias_radial'],
			pattern_design => $_POST['pattern_design'],
			pr_loadindex => $_POST['pr_loadindex'],
			speed_rating => $_POST['speed_rating'],
			description_tyre_sno => $_POST['description_tyre_sno'],
			nsd_at_twi_mm => $_POST['nsd_at_twi_mm'],
			dealer_fleet_registration_code => $_POST['dealer_fleet_registration_code'],
			tyre_band_ply => $_POST['tyre_band_ply'],
			upload_tyre_sno => $_POST['upload_tyre_sno'],
			invoice_photo => $_POST['invoice_photo'],
			vehicle_brand => $_POST['vehicle_brand'],
			vehicle_regno => $_POST['vehicle_regno'],
			nameof_registered_owner => $_POST['nameof_registered_owner'],
			fitment_position => $_POST['fitment_position'],
			mobile_country_code => $_POST['mobile_country_code'],
			emailid => $_POST['emailid'],
			nominee_name_relationship => $_POST['nominee_name_relationship'],
			running_wheels => $_POST['running_wheels'],
			fitment_photo => $_POST['fitment_photo'],
			fullvehicle_photo => $_POST['fullvehicle_photo'],
        );
		$this->db->insert('tyre_registraion',$data);
        $result = $this->db->insert_id();
        return $result; 
    }
	
	function upload(){
        $data = array(
			tyre_registraion_id => $_POST['tyre_registraion_id'],
			registration => $_POST['registration'],
			type_of_vehicle => $_POST['type_of_vehicle'],
			tyre_size => $_POST['tyre_size'],
			description_brand => $_POST['description_brand'],
			bias_radial => $_POST['bias_radial'],
			pattern_design => $_POST['pattern_design'],
			pr_loadindex => $_POST['pr_loadindex'],
			speed_rating => $_POST['speed_rating'],
			description_tyre_sno => $_POST['description_tyre_sno'],
			nsd_at_twi_mm => $_POST['nsd_at_twi_mm'],
			dealer_fleet_registration_code => $_POST['dealer_fleet_registration_code'],
			tyre_band_ply => $_POST['tyre_band_ply'],
			upload_tyre_sno => $_POST['upload_tyre_sno'],
			invoice_photo => $_POST['invoice_photo'],
			vehicle_brand => $_POST['vehicle_brand'],
			vehicle_regno => $_POST['vehicle_regno'],
			nameof_registered_owner => $_POST['nameof_registered_owner'],
			fitment_position => $_POST['fitment_position'],
			mobile_country_code => $_POST['mobile_country_code'],
			emailid => $_POST['emailid'],
			nominee_name_relationship => $_POST['nominee_name_relationship'],
			running_wheels => $_POST['running_wheels'],
			fitment_photo => $_POST['fitment_photo'],
			fullvehicle_photo => $_POST['fullvehicle_photo'],
        );
		$this->db->insert('tyre_registraion',$data);
        $result = $this->db->insert_id();
        return $result; 
    }

}