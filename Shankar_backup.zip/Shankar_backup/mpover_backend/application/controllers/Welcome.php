<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include 'PHPMailer.php';
class Welcome extends CI_Controller {
	public function  __construct()
  {
     parent::__construct();
     $this->load->library('form_validation');
     $$this->load->helper('url');
  }
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function add()
	{
		
		$mail = new PHPMailer(); 
		$mail->AddAddress('vignessh@smaatapps.com');
		$mail->IsMail();
		$mail->From = $this->input->post('email');
		$mail->FromName = $this->input->post('name');
		$mail->IsHTML(true);
		$mail->Subject = "Mpover Contact form";
		$mail->Body = $this->input->post('mobile');

		if (!$mail->Send()) {
			echo "Mailer Error: " . $mail->ErrorInfo;
			$data['mail']="error";
			//$this->load->view('contact',$data);
		} else {
			$data['mail']="success";	
			$mail->AddAddress($_POST['email']);
			$mail->IsMail();
			$mail->From = 'vignessh@smaatapps.com';
			$mail->FromName = 'Mpover';
			$mail->IsHTML(true);
			$mail->Subject = "Mpover Contact form";
			$mail->Body = $this->input->post('mobile');
			$mail->Send();
			//$this->load->view('contact',$data);
			
		}
		
		$data = array(
				"name" => $this->input->post('name'),
				"email" => $this->input->post('email'),
				"mobile" => $this->input->post('mobile'),
				"state" => $this->input->post('state'),
				"city" => $this->input->post('city'),
				"dealer" => $this->input->post('dealer'),

		);
		$this->db->insert('contact', $data);
			
	}

        }
		public function services()
		{
			$this->load->view('services');
		}
}
