<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* 
*
* Class: Amc_customer_list
*
* Index Function for this controller is used to list AMC Customer list from database.
* @package    CodeIgniter
* @subpackage Amc_customer_list
* @category   Rest API
* @author     Vishnuraj KN
* @copyright  2018 http://smaatapps.com
*
*
* Error status code
* 200 - OK
* 201 - Created
* 202 - INVALID ACCESS
* 400 - BAD REQUEST
*
*
*/

require APPPATH.'/libraries/REST_Controller.php';


class Amc_customer_list extends REST_Controller 
{
	
	public function __construct()
	{
		parent::__construct();		
		$this->load->model('Amc_customer_list_model');		
	}
	
	public function index_post()
	{
		if(isset($_POST)!= "")
		{
				$result = $this->Amc_customer_list_model->index();
				$msg=array("error_code"=>"1","msg"=>"Success","result"=>$result);
				$this->response($msg,202);
			
		}
		else
		{
				$result = "invalid";
				$msg = array("error_code" => "1","msg" =>"fail","result" => $result);
				$this->response($result, 201);
		}
		
	}
	
}
?>