<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Categorylist_model extends CI_Model{
	public function __construct()
	{
		parent::__construct();
		
		
    }
    function index(){
		$this->db->select('*');
		$this->db->from('product_category');
		$query = $this->db->get();
		$results = $query->result_array();
		if(sizeof($results)==0) {
			$results = "No Category Found";
			return $results;
		} else {
			return $results;
		}        
    }

}